// ============================================================
// Nirapod survey — configuration
// ============================================================
// Paste the Google Apps Script Web App URL here after deploying
// Code.gs (see README.md, Step 3). It looks like:
// https://script.google.com/macros/s/AKfycb.../exec
const ENDPOINT_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_URL_HERE";

// ============================================================
// Question definitions — mirrors the Nirapod Google Form
// ============================================================
const SECTIONS = [
  {
    label: "Demographics & usage background",
    questions: [
      {
        id: "age_group", type: "radio", required: true,
        title: "What is your age group?",
        options: ["Under 18", "18–24", "25–34", "35–44", "45–54", "55 or above", "Prefer not to say"]
      },
      {
        id: "hand_used", type: "radio", required: true,
        title: "Which hand do you normally use to operate your phone?",
        options: ["Left hand", "Right hand", "Both hands equally", "It depends on the situation"]
      },
      {
        id: "transit_frequency", type: "radio", required: true,
        title: "How often do you use public transportation/transit?",
        options: ["Daily", "Several times a week", "Once a week", "A few times a month", "Rarely"]
      }
    ]
  },
  {
    label: "Phone behaviour under stress",
    questions: [
      {
        id: "small_buttons_difficulty", type: "likert", required: true,
        title: "I find it difficult to accurately press small buttons when my hands are moving.",
        help: "During stressful moments — running, a panic feeling, or feeling threatened — how usable is your phone, really?",
        capLow: "Disagree", capHigh: "Agree"
      },
      {
        id: "prefers_minimal_interaction", type: "likert", required: true,
        title: "I would prefer an emergency function that requires minimal interaction.",
        capLow: "Disagree", capHigh: "Agree"
      },
      {
        id: "unsafe_response", type: "checkbox", required: true,
        title: "If you suddenly felt unsafe while travelling, what would you most likely do?",
        options: [
          "Try to contact someone I trust",
          "Move to a safer/crowded location",
          "Contact emergency services",
          "Use an SOS/emergency feature on my phone",
          "Ask a nearby person for help",
          "Leave the vehicle/station as soon as possible"
        ],
        allowOther: true
      }
    ]
  },
  {
    label: "Trust & emergency trigger preference",
    questions: [
      {
        id: "auto_detection_usefulness", type: "likert", required: true,
        title: "How useful would an automatic emergency detection feature be?",
        capLow: "Not useful", capHigh: "Strongly useful"
      },
      {
        id: "auto_alert_trust", type: "likert", required: true,
        title: "How much would you trust an emergency alert triggered automatically by the application?",
        capLow: "Not at all", capHigh: "Greatly trustable"
      },
      {
        id: "preferred_trigger", type: "radio", required: true,
        title: "Which emergency trigger would you prefer?",
        options: ["SOS button", "Shake the phone", "Power-button press"],
        allowOther: true
      },
      {
        id: "sos_scenario_response", type: "text", required: false,
        title: "In a scenario like getting mugged, or a sudden dangerous one — if you needed to send an SOS signal, how would you want to do it?",
        help: "Optional — answer in your own words."
      },
      {
        id: "cancel_window_wanted", type: "radio", required: true,
        title: "Would you want a short period to cancel an emergency alert before it is sent?",
        options: ["Yes", "No", "Maybe"]
      }
    ]
  },
  {
    label: "Bystander response",
    questions: [
      {
        id: "bystander_response_likelihood", type: "likert", required: true,
        title: "What are the chances that you will actually respond to the distress signal?",
        capLow: "I might ignore", capHigh: "Yes, I will"
      },
      {
        id: "bystander_motivators", type: "checkbox", required: true,
        title: "What would make you more likely to respond to an emergency notification from a nearby person?",
        help: "Select all that apply.",
        options: [
          "Clear indication that the situation is an emergency",
          "Approximate location of the person",
          "Information about what type of help is needed",
          "Ability to contact the person",
          "Confirmation from multiple nearby users",
          "Emergency services involvement"
        ],
        allowOther: true
      },
      {
        id: "wants_interview", type: "radio", required: true,
        title: "If we conduct an interview later, would you like to participate?",
        options: ["Yes", "No"],
        allowOther: true
      }
    ]
  }
];

// Flatten into a single ordered step list, with an intro step at index 0
const STEPS = [{ kind: "intro" }];
SECTIONS.forEach((section, sIdx) => {
  section.questions.forEach((q) => {
    STEPS.push({ kind: "question", section, sectionIndex: sIdx, q });
  });
});
STEPS.push({ kind: "submit" });

// ============================================================
// State
// ============================================================
let current = 0;
const answers = {};
const root = document.getElementById("app-root");
const progressFill = document.getElementById("progressFill");
const progressLabel = document.getElementById("progressLabel");

function updateProgress() {
  const pct = Math.round((current / (STEPS.length - 1)) * 100);
  progressFill.style.width = pct + "%";
  const step = STEPS[current];
  progressLabel.textContent =
    step.kind === "question" ? `Section ${step.sectionIndex + 1} of ${SECTIONS.length}` : "";
}

function render() {
  updateProgress();
  const step = STEPS[current];
  root.innerHTML = "";

  if (step.kind === "intro") return renderIntro();
  if (step.kind === "submit") return renderSubmit();
  return renderQuestion(step);
}

function renderIntro() {
  root.innerHTML = `
    <div class="intro">
      <p class="subtitle">The Virtual Art of Actual Safety</p>
      <h1>Help design a safer commute.</h1>
      <p>This short survey looks at how people actually use their phones during stressful or unsafe moments on public transit, and what kind of emergency feature would feel usable in that moment.</p>
      <p>It takes about 4–5 minutes. You will not be asked to describe any personal experience of assault or harm — this study only asks about habits and preferences.</p>
      <div class="meta-row">
        <span>~4–5 minutes</span>
        <span>${SECTIONS.length} short sections</span>
        <span>Fully anonymous</span>
      </div>
    </div>
    <div class="nav-row">
      <button class="btn-primary" id="startBtn">Start the survey</button>
    </div>
  `;
  document.getElementById("startBtn").onclick = () => go(1);
}

function renderQuestion(step) {
  const { q } = step;
  const wrap = document.createElement("div");
  wrap.className = "q-body";

  let bodyHtml = "";
  if (q.type === "radio" || q.type === "checkbox") {
    bodyHtml = renderChoiceOptions(q);
  } else if (q.type === "likert") {
    bodyHtml = renderLikert(q);
  } else if (q.type === "text") {
    const val = answers[q.id] || "";
    bodyHtml = `<textarea class="other-input" id="textInput" placeholder="Type your answer...">${escapeHtml(val)}</textarea>`;
  }

  root.innerHTML = `
    <p class="q-eyebrow">${step.section.label}</p>
    <h2 class="q-title">${q.title}</h2>
    ${q.help ? `<p class="q-help">${q.help}</p>` : ""}
    <div class="q-body">${bodyHtml}</div>
    <p class="error-msg" id="errorMsg"></p>
    <div class="nav-row">
      <button class="btn-ghost" id="backBtn">Back</button>
      <button class="btn-primary" id="nextBtn">${current === STEPS.length - 2 ? "Review" : "Next"}</button>
    </div>
  `;

  attachChoiceHandlers(q);
  document.getElementById("backBtn").onclick = () => go(-1);
  document.getElementById("nextBtn").onclick = () => tryAdvance(q);
}

function renderChoiceOptions(q) {
  const stored = answers[q.id] || (q.type === "checkbox" ? [] : { value: "", other: "" });
  const isChecked = (opt) =>
    q.type === "checkbox" ? stored.includes(opt) : stored.value === opt;

  let html = `<div class="options">`;
  q.options.forEach((opt, i) => {
    const inputType = q.type === "checkbox" ? "checkbox" : "radio";
    html += `
      <label class="option ${isChecked(opt) ? "checked" : ""}" data-opt="${escapeAttr(opt)}">
        <input type="${inputType}" name="${q.id}" value="${escapeAttr(opt)}" ${isChecked(opt) ? "checked" : ""}>
        <span>${opt}</span>
      </label>`;
  });
  if (q.allowOther) {
    const otherChecked = q.type === "checkbox" ? stored.includes("Other") : stored.value === "Other";
    html += `
      <label class="option ${otherChecked ? "checked" : ""}" data-opt="Other">
        <input type="${q.type === "checkbox" ? "checkbox" : "radio"}" name="${q.id}" value="Other" ${otherChecked ? "checked" : ""}>
        <span>Other</span>
      </label>
      <input type="text" class="other-input" id="otherText" placeholder="Please specify"
        value="${escapeAttr((q.type === "checkbox" ? stored.otherText : stored.other) || "")}"
        style="display:${otherChecked ? "block" : "none"}">`;
  }
  html += `</div>`;
  return html;
}

function renderLikert(q) {
  const stored = answers[q.id] || null;
  let html = `<div class="likert">`;
  for (let i = 1; i <= 5; i++) {
    html += `
      <label class="likert-item">
        <input type="radio" name="${q.id}" value="${i}" ${stored === i ? "checked" : ""}>
        <span class="likert-dot">${i}</span>
        <span class="likert-cap">${i === 1 ? q.capLow : i === 5 ? q.capHigh : "&nbsp;"}</span>
      </label>`;
  }
  html += `</div>`;
  return html;
}

function attachChoiceHandlers(q) {
  if (q.type !== "radio" && q.type !== "checkbox") return;
  const options = root.querySelectorAll(".option");
  options.forEach((optEl) => {
    optEl.addEventListener("click", (e) => {
      if (e.target.tagName === "INPUT") return; // let native input handle it, then sync below
      const input = optEl.querySelector("input");
      if (q.type === "checkbox") input.checked = !input.checked;
      else input.checked = true;
      syncChoiceUI(q);
    });
  });
  root.querySelectorAll(`input[name="${q.id}"]`).forEach((inp) => {
    inp.addEventListener("change", () => syncChoiceUI(q));
  });
  const otherText = document.getElementById("otherText");
  if (otherText) otherText.addEventListener("input", () => syncChoiceUI(q));
}

function syncChoiceUI(q) {
  root.querySelectorAll(".option").forEach((el) => {
    const input = el.querySelector("input");
    el.classList.toggle("checked", input.checked);
  });
  const otherInput = root.querySelector(`input[value="Other"]`);
  const otherText = document.getElementById("otherText");
  if (otherText) otherText.style.display = otherInput && otherInput.checked ? "block" : "none";
}

function collectAnswer(q) {
  if (q.type === "text") {
    const v = document.getElementById("textInput").value.trim();
    return v;
  }
  if (q.type === "likert") {
    const checked = root.querySelector(`input[name="${q.id}"]:checked`);
    return checked ? parseInt(checked.value, 10) : null;
  }
  if (q.type === "radio") {
    const checked = root.querySelector(`input[name="${q.id}"]:checked`);
    const otherText = document.getElementById("otherText");
    return { value: checked ? checked.value : "", other: otherText ? otherText.value.trim() : "" };
  }
  if (q.type === "checkbox") {
    const checked = [...root.querySelectorAll(`input[name="${q.id}"]:checked`)].map((i) => i.value);
    const otherText = document.getElementById("otherText");
    const result = checked;
    result.otherText = otherText ? otherText.value.trim() : "";
    return result;
  }
}

function isAnswerEmpty(q, val) {
  if (q.type === "text") return val === "";
  if (q.type === "likert") return val === null;
  if (q.type === "radio") return !val.value;
  if (q.type === "checkbox") return !val || val.length === 0;
  return true;
}

function tryAdvance(q) {
  const val = collectAnswer(q);
  answers[q.id] = val;
  const errorEl = document.getElementById("errorMsg");
  if (q.required && isAnswerEmpty(q, val)) {
    errorEl.textContent = "Please answer this question to continue.";
    return;
  }
  errorEl.textContent = "";
  go(1);
}

function go(delta) {
  current += delta;
  render();
}

function renderSubmit() {
  root.innerHTML = `
    <div class="intro">
      <p class="subtitle">Almost done</p>
      <h1>Ready to submit your responses.</h1>
      <p>Your answers are anonymous — no name, phone number, or identifying details are collected. Thank you for helping shape a safer transit experience.</p>
    </div>
    <p class="error-msg" id="errorMsg"></p>
    <div class="nav-row">
      <button class="btn-ghost" id="backBtn">Back</button>
      <button class="btn-primary" id="submitBtn">Submit responses</button>
    </div>
  `;
  document.getElementById("backBtn").onclick = () => go(-1);
  document.getElementById("submitBtn").onclick = submitSurvey;
}

async function submitSurvey() {
  root.innerHTML = `
    <div class="status-screen">
      <div class="spinner"></div>
      <h2>Sending your responses…</h2>
    </div>
  `;

  const payload = { submitted_at: new Date().toISOString() };
  SECTIONS.forEach((section) => {
    section.questions.forEach((q) => {
      const val = answers[q.id];
      payload[q.id] = flattenAnswer(q, val);
    });
  });

  try {
    if (!ENDPOINT_URL || ENDPOINT_URL.includes("PASTE_YOUR")) {
      throw new Error("NO_ENDPOINT");
    }
    await fetch(ENDPOINT_URL, {
      method: "POST",
      // text/plain avoids a CORS preflight that Apps Script web apps can't answer
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(payload)
    });
    renderDone(true);
  } catch (err) {
    renderDone(false, err.message === "NO_ENDPOINT");
  }
}

function flattenAnswer(q, val) {
  if (val == null) return "";
  if (q.type === "radio") {
    return val.value === "Other" && val.other ? `Other: ${val.other}` : val.value;
  }
  if (q.type === "checkbox") {
    const list = [...val];
    if (list.includes("Other") && val.otherText) {
      const idx = list.indexOf("Other");
      list[idx] = `Other: ${val.otherText}`;
    }
    return list.join("; ");
  }
  return val;
}

function renderDone(success, noEndpoint) {
  if (success) {
    root.innerHTML = `
      <div class="status-screen">
        <h2>Thank you.</h2>
        <p>Your response has been recorded. It will help build a safer, more usable emergency feature for transit riders.</p>
      </div>
    `;
  } else {
    root.innerHTML = `
      <div class="status-screen">
        <h2>Something went wrong.</h2>
        <p>${noEndpoint
          ? "This survey isn't connected to a Google Sheet yet — add the Apps Script URL in script.js (see README.md)."
          : "Your response could not be sent. Please check your connection and try again."}</p>
        <button class="btn-primary" id="retryBtn">Try again</button>
      </div>
    `;
    document.getElementById("retryBtn").onclick = submitSurvey;
  }
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function escapeAttr(str) { return escapeHtml(str); }

render();
